package com.cts.InterviewSchedulingManagement.service;

import com.cts.InterviewSchedulingManagement.bean.Candidate;

public interface RegistrationService  {
	
	public String registerCandidate(Candidate candidate);

}
